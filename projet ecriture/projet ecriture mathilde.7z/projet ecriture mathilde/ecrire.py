import alphabet
from turtle import*
import random as r

def ecrire(texte,taille,épaisseur,couleur,souligne):
    reset()
    tailleTotale=0
    if épaisseur=="oui":
        width(3)
    for lettre in texte:
        curTaille = taille
        code=ord(lettre)
        if code>=65 and code<=90:
            lettre=chr(code+32)
            curTaille=1.3*taille
            code=ord(lettre)
        if code==32:
            tailleTotale+=curTaille
        if code==39:
             tailleTotale+=alphabet.largeur_apos(curTaille)
        elif code>=97 and code<=122:
            tailleTotale+=getattr(alphabet, "largeur_"+lettre)(curTaille)
        else:
            tailleTotale+=taille
        tailleTotale+=0.25*taille
    
    up()
    forward(-tailleTotale/2)
    down()
    
    for lettre in texte:
        if couleur=="aléatoire":
            couleurs=["blue","green","red","cyan","magenta","yellow","black","white"]
            color(couleurs[r.randint(0, 7)])
        else:
            color(couleur)
        curTaille = taille
        code=ord(lettre)
        if code>=65 and code<=90:
            lettre=chr(code+32)
            curTaille=1.3*taille
            code=ord(lettre)
        
        if code==32:
            alphabet.space(curTaille)
        if code==39:
            alphabet.apos(curTaille)
        elif code>=97 and code<=122:
            getattr(alphabet, lettre)(curTaille)
        else:
            alphabet.space(curTaille)
            
        alphabet.interlettre(curTaille)
         
    if souligne=="oui":
        up()
        forward(-tailleTotale)
        right(90)
        forward(0.5*taille)
        left(90)
        down()
        forward(tailleTotale+0.5*taille)