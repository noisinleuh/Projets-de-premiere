import alphabet
from turtle import*
import random as r


def ecrire(texte, taille, épaisseur, couleur, souligne):
    reset()    
    hideturtle()
    #remise à 0 des variables#
    tailleTotale = 0
    smile = 0
    coeur = 0
    #défini que le texte est en gras quand demandé par l'utilisateur#
    if épaisseur == "oui":
        width(3)
    #calcul la taille totale de la phrase#
    for lettre in texte:
        #curTaille est la taille courante de la lettre permettant de définir les majuscules#
        curTaille = taille
        #code est le nombre ascii de la lettre#
        code = ord(lettre)
        #41 est ) cela défini si il faut faire un smiley#
        if code == 41:
            if smile == 1:
                tailleTotale += alphabet.largeur_smile(curTaille)
                smile = 2
            else:
                smile = 0
        #lettres majuscules#
        if code >= 65 and code <= 90:
            #remplace la variable lettre (en majuscule) par son analogue minuscule#
            lettre = chr(code+32)
            #augmente la taille de la lettre pour la majuscule#
            curTaille = 1.3*taille
            code = ord(lettre)
        #espace#
        if code == 32:
            tailleTotale += curTaille*2/3
        #apostrophe#
        if code == 39:
            tailleTotale += alphabet.largeur_apos(curTaille)
        #deux points ajoute 1 à smile afin que si le symbole suivant est ) on rend la taille d'un smiley#
        if code == 58:
            smile = 1
        #< ajoute 1 à coeur afin que si le symbole suivant est 3 on rend la taille d'un coeur#
        if code == 60:
            coeur = 1
        #chiffres#
        if code >= 48 and code <= 57:
            #remplace le chiffre par son nom#
            if code == 48:
                lettre = "zéro"
            if code == 49:
                lettre = "un"
            if code == 50:
                lettre = "deux"
            if code == 51:
                #si le symbole précédent est un < le programme utilise la taille du coeur#
                if coeur == 1:
                    tailleTotale += alphabet.largeur_coeur(curTaille)
                    coeur = 2
                else:
                    coeur = 0
                    #sinon le programme utilise celle du 3#
                    lettre = "trois"
            if code == 52:
                lettre = "quatre"
            if code == 53:
                lettre = "cinq"
            if code == 54:
                lettre = "six"
            if code == 55:
                lettre = "sept"
            if code == 56:
                lettre = "huit"
            if code == 57:
                lettre = "neuf"
        #lettres, chiffres, lettres avec accent é, è, à et si le trois n'est pas utilisé pour un coeur#
        if code >= 97 and code <= 122 or code >= 48 and code <= 57 and coeur != 2 or code == 224 or code == 232 or code == 233:
            #la taille totale de la ligne correspond à elle même plus la fonction largeur_ suivie de la lettre dans le circuit alphabet de la taille curTaille#
            tailleTotale += getattr(alphabet, "largeur_"+lettre)(curTaille)
        else:
            #si la lettre n'est pas défini on utilise la taille d'un espace#
            tailleTotale += taille*2/3
        #on fini par un petit espace pour séparer les lettres et qu'elle ne soit pas collées#
        tailleTotale += 0.25*taille
    
    #centre le texte en utilisant la taille totale#
    up()
    forward(-tailleTotale/2)
    down()
    
    #écrit la phrase#
    for lettre in texte:
        #couleur aléatoire une couleur par lettre au hasard#
        if couleur == "aléatoire":
            couleurs = ["blue", "green", "red",
                        "cyan", "magenta", "yellow", "black"]
            color(couleurs[r.randint(0, 6)])
        else:
            #utilise la variable couleur définie par l'utilisateur#
            color(couleur)
        curTaille = taille
        code = ord(lettre)
        #majuscules#
        if code >= 65 and code <= 90:
            lettre = chr(code+32)
            curTaille = 1.3*taille
            code = ord(lettre)
        #espace#
        if code == 32:
            alphabet.space(curTaille)
        #apostrophe#
        if code == 39:
            alphabet.apos(curTaille)
        #point d'exclamation#
        if code == 33:
            alphabet.exc(curTaille)
        #point d'interrogation#
        if code == 63:
            alphabet.intero(curTaille)
        #point#
        if code == 46:
            alphabet.point(curTaille)
        #) fait un smiley si la lettre précédente était un :#
        if code == 41:
            if smile == 1:
                None
            if smile == 2:
                alphabet.smile(curTaille)
        #chiffres#
        if code >= 48 and code <= 57:
            #remplace le chiffre par son nom#
            if code == 48:
                lettre = "zéro"
            if code == 49:
                lettre = "un"
            if code == 50:
                lettre = "deux"
            #si le symbole précédent est un < le programme dessine un coeur#
            if code == 51:
                if coeur == 1:
                    None
                if coeur == 2:
                    alphabet.coeur(curTaille)
                else:
                    #sinon le programme fait un 3#
                    lettre = "trois"
            if code == 52:
                lettre = "quatre"
            if code == 53:
                lettre = "cinq"
            if code == 54:
                lettre = "six"
            if code == 55:
                lettre = "sept"
            if code == 56:
                lettre = "huit"
            if code == 57:
                lettre = "neuf"
        #lettres, chiffres, lettres avec accent é, è, à et si le trois n'est pas utilisé pour un coeur#
        if code >= 97 and code <= 122 or code >= 48 and code <= 57 and coeur != 2 or code == 224 or code == 232 or code == 233:
            #le programme dessine la lettre ou le chiffre en utilisant la fonction du même nom dans le module alphabet de la taille curTaille#
            getattr(alphabet, lettre)(curTaille)
        else:
            #si la lettre n'est pas définie on fait un espace#
            alphabet.space(curTaille)
        #quoi qu'il arrive on fait un espace pour séparer les lettres entre elles#
        alphabet.interlettre(curTaille)

    #souligne le texte quand demandé par l'utilisateur#
    if souligne == "oui":
        up()
        forward(-tailleTotale)
        right(90)
        forward(0.5*taille)
        left(90)
        down()
        forward(tailleTotale)
